// Estrutura inicial — as telas (Login, Abertura, Painel do Gestor, Execução do
// Técnico, Relatórios) serão implementadas em pages/ seguindo o protótipo HTML
// já aprovado (prototipo-sistema-manutencao.html).
function App() {
  return (
    <div className="min-h-screen bg-[#EEF1F5] flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-navy">Sistema de Manutenção Predial</h1>
        <p className="text-sm text-gray-500 mt-2">Front-end em construção — próximas etapas nas pages/</p>
      </div>
    </div>
  );
}

export default App;
