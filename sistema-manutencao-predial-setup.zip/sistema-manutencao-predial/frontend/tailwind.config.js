/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Paleta do protótipo (prototipo-sistema-manutencao.html)
        navy: '#1F3864',
        'navy-2': '#16294B',
        amber: '#D98C2B',
      },
    },
  },
  plugins: [],
};
