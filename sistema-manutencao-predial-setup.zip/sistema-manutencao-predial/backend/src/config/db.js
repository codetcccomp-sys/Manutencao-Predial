const { Pool } = require('pg');
require('dotenv').config();

// RNF06: banco de dados relacional (PostgreSQL)
const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

pool.on('error', (err) => {
  // Erro em conexão ociosa do pool — nunca deve derrubar a API silenciosamente
  console.error('Erro inesperado no pool do PostgreSQL:', err);
});

module.exports = pool;
