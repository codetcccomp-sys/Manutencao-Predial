# Sistema de Manutenção Predial

Estrutura inicial do projeto, conforme `Stack_Tecnica.docx` e o Termo de Abertura.

## Estrutura

```
sistema-manutencao-predial/
├── backend/
│   ├── database/schema.sql       # DDL PostgreSQL com as 11 entidades do modelo de dados
│   └── src/
│       ├── config/db.js          # Pool de conexão PostgreSQL
│       ├── middlewares/
│       │   ├── auth.js           # JWT + autorização por perfil (RNF01)
│       │   └── errorHandler.js   # Tratamento central de erros
│       ├── routes/                # Rotas por recurso (a implementar)
│       ├── controllers/           # Controllers (a implementar)
│       ├── services/              # Regras de negócio (a implementar)
│       ├── app.js                # Configuração do Express
│       └── server.js             # Entry point
└── frontend/
    └── src/
        ├── pages/                 # Telas (Login, Abertura, Painel, Técnico, Relatórios)
        ├── components/
        ├── services/               # Clientes HTTP (axios) para a API
        └── App.jsx
```

## Como rodar (ambiente de desenvolvimento)

### Banco de dados
1. Crie um banco PostgreSQL local (ex.: `smp`).
2. Execute o script: `psql -U seu_usuario -d smp -f backend/database/schema.sql`

### Backend
```bash
cd backend
cp .env.example .env   # preencha DB_*, JWT_SECRET, etc.
npm install
npm run dev             # sobe em http://localhost:3333
```
Teste rápido: `GET http://localhost:3333/health` deve responder `{"status":"ok", ...}`.

### Frontend
```bash
cd frontend
npm install
npm run dev              # sobe em http://localhost:5173
```

## Observações importantes desta etapa

- **RN08 (prazo suspenso)**: o dicionário de dados original não previa campos para controlar
  a suspensão de prazo durante "aguardando material". Foram adicionados os campos técnicos
  `aguardando_material_desde` e `tempo_suspenso_total` na tabela `chamado` — confirme se essa
  abordagem atende antes de seguirmos para a lógica de negócio dessa regra.
- **RN05 x RN09 (reabertura)**: adotada a interpretação de que Solicitante OU Gestor podem
  solicitar reabertura em até 48h (RN09), enquanto RN05 permanece válida para prioridade,
  atribuição e cancelamento (exclusivos do Gestor).
- Nenhuma rota de negócio foi implementada ainda — apenas a fundação (conexão com banco,
  autenticação/autorização, tratamento de erros, estrutura de pastas).
